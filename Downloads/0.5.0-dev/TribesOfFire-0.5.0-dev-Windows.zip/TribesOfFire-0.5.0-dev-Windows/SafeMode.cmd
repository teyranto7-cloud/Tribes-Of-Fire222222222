@echo off
cd /d "%~dp0"
"%~dp0TribesOfFire.exe" -- --safe
